package tictactoe;

public class Game {
    public static void main(String[] args) {
        GameScreen screen = new GameScreen("Tic tac Toe", 300, 300);

    }
}
